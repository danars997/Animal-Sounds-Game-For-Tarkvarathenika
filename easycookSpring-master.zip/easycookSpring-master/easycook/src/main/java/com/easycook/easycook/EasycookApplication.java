package com.easycook.easycook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EasycookApplication {

	public static void main(String[] args) {
		SpringApplication.run(EasycookApplication.class, args);
	}
}
